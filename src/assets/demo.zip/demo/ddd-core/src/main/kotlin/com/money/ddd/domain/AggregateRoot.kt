package com.money.ddd.domain

/**
 * AggregateRoot로서 BoundedContext에 해당하는 Domain들을 명시
 */
interface AggregateRoot<T : AggregateRoot<T, ID>, ID> : DomainEntity<T, ID>
