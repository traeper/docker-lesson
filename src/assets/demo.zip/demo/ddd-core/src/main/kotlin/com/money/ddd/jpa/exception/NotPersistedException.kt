package com.money.ddd.jpa.exception

/**
 * @author traeper
 */
class NotPersistedException : RuntimeException()
