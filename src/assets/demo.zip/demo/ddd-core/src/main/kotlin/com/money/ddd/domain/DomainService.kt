package com.money.ddd.domain

import org.springframework.stereotype.Service

/**
 * @author traeper
 */
@Service
annotation class DomainService
