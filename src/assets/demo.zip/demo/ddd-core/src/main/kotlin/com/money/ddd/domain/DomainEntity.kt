package com.money.ddd.domain

/**
 * @author traeper
 */
interface DomainEntity<T : AggregateRoot<T, ID>, ID> {
    fun getId(): ID
}
