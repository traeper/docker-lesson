package com.money.ddd.domain

import java.time.ZonedDateTime
import javax.persistence.Column
import javax.persistence.MappedSuperclass
import javax.persistence.PrePersist
import javax.persistence.PreUpdate

/**
 * @author traeper
 */
@MappedSuperclass
abstract class AbstractSystemEntity {
    @Column(nullable = false, updatable = false)
    open var insertDateTime: ZonedDateTime = ZonedDateTime.now()

    @Column(nullable = false)
    open var updateDateTime: ZonedDateTime = ZonedDateTime.now()

    @PrePersist
    fun prePersist() {
        val now = ZonedDateTime.now()
        insertDateTime = now
        updateDateTime = now
    }

    @PreUpdate
    fun preUpdate() {
        updateDateTime = ZonedDateTime.now()
    }
}
