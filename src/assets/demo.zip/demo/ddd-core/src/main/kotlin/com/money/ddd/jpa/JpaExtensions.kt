package com.money.ddd.jpa

import com.money.ddd.jpa.exception.NotPersistedException

/**
 * JPA Entity id 값이 제대로 채번되지 않았는지(==null) 체크.
 * @author traeper
 */
fun <T> T?.checkPersisted(): T {
    return this ?: throw NotPersistedException()
}
