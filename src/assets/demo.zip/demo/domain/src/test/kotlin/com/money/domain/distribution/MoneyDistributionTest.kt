package com.money.domain.distribution

import com.money.common.util.NumberDistributor
import com.money.domain.distribution.TicketStatus.NORMAL
import com.money.domain.distribution.exception.DistributionDoneException
import com.money.domain.distribution.exception.InvalidParameterException
import com.money.domain.distribution.exception.SearchDisabledException
import com.money.domain.distribution.service.MoneyDistributionService
import com.money.domain.user.UserRepository
import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.assertThrows
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest
import org.springframework.test.context.jdbc.Sql

/**
 * @author traeper
 */
@DataJpaTest
class MoneyDistributionTest {

    @Autowired
    private lateinit var moneyDistributionRepository: MoneyDistributionRepository

    @Autowired
    private lateinit var moneyDistributionTicketRepository: MoneyDistributionTicketRepository

    @Autowired
    private lateinit var moneyDistributionTicketReceiptRepository: MoneyDistributionTicketReceiptRepository

    @Autowired
    private lateinit var userRepository: UserRepository

    private lateinit var moneyDistributionService: MoneyDistributionService

    @BeforeEach
    internal fun setUp() {
        moneyDistributionService = MoneyDistributionService(
            moneyDistributionRepository = moneyDistributionRepository,
            moneyDistributionTicketRepository = moneyDistributionTicketRepository,
            moneyDistributionTicketReceiptRepository = moneyDistributionTicketReceiptRepository,
            userRepository = userRepository
        )
    }

    @Test
    internal fun `잘못된 userId가 입력되면 예외가 발생한다`() {
        // GIVEN
        val userId = -1L
        val totalMoney = 10000L
        val distributionCount = 5
        val token = "abc"

        // WHEN, THEN
        assertThrows<InvalidParameterException> {
            moneyDistributionService.distributeMoney(
                userId = userId,
                totalMoney = totalMoney,
                distributionCount = distributionCount,
                token = token,
                numberDistributor = NumberDistributor::distribute
            )
        }
    }

    @Test
    internal fun `잘못된 분배 총액이 입력되면 예외가 발생한다`() {
        // GIVEN
        val userId = 1L
        val totalMoney = -10000L
        val distributionCount = 5
        val token = "abc"

        // WHEN, THEN
        assertThrows<InvalidParameterException> {
            moneyDistributionService.distributeMoney(
                userId = userId,
                totalMoney = totalMoney,
                distributionCount = distributionCount,
                token = token,
                numberDistributor = NumberDistributor::distribute
            )
        }
    }

    @Test
    internal fun `잘못된 분배 개수가 입력되면 예외가 발생한다`() {
        // GIVEN
        val userId = 1L
        val totalMoney = 10000L
        val distributionCount = -5
        val token = "abc"

        // WHEN, THEN
        assertThrows<InvalidParameterException> {
            moneyDistributionService.distributeMoney(
                userId = userId,
                totalMoney = totalMoney,
                distributionCount = distributionCount,
                token = token,
                numberDistributor = NumberDistributor::distribute
            )
        }
    }

    @Test
    internal fun `돈을 분배하면 원하는 갯수만큼 분배되며 합은 totalMoney와 같다`() {
        // GIVEN
        val userId = 1L
        val totalMoney = 10000L
        val distributionCount = 5
        val token = "ABC"

        // WHEN
        val distribution = moneyDistributionService.distributeMoney(
            userId = userId,
            totalMoney = totalMoney,
            distributionCount = distributionCount,
            token = token,
            numberDistributor = NumberDistributor::distribute
        )

        // THEN
        assertThat(distribution.token).withFailMessage("token은 입력된 토큰값이어야 한다.").isEqualTo(token)
        val tickets = moneyDistributionTicketRepository.findAll()
        assertThat(tickets.size).isEqualTo(distributionCount)
        assertThat(tickets.sumOf { it.money }).isEqualTo(totalMoney)
    }

    @Sql("/data/money-distribution-done.sql")
    @Test
    internal fun `돈 분배 완료된 건에 대한 받기 요청은 실패한다`() {
        // GIVEN
        val userId = 1L
        val token = "a12"

        assertThrows<DistributionDoneException> {
            // WHEN
            moneyDistributionService.receiveMoney(userId, token)
        }
    }

    @Sql("/data/money-distribution-old.sql")
    @Test
    internal fun `돈 분배한지 10분 넘은 오래된 건에 대한 받기 요청은 실패한다`() {
        // GIVEN
        val userId = 2L
        val token = "a12"

        assertThrows<DistributionDoneException> {
            // WHEN
            moneyDistributionService.receiveMoney(userId, token)
        }
    }

    @Sql("/data/money-distribution.sql")
    @Test
    internal fun `분배된 머니 티켓 첫 번째 티켓을 받는다`() {
        // GIVEN
        val userId = 2L
        val token = "a12"

        // WHEN
        val ticket = moneyDistributionService.receiveMoney(userId, token)

        // THEN
        assertThat(ticket.moneyDistributionTicketId).withFailMessage("NORMAL 티켓 중 첫 번째 티켓이 선택된다.").isEqualTo(1L)
        assertThat(ticket.money).isEqualTo(1500L)
        assertThat(ticket.moneyDistributionId).isEqualTo(1L)
        assertThat(ticket.status).isEqualTo(TicketStatus.RECEIPT_COMPLETE)
        assertThat(ticket.receiveCompletedDateTime).isNotNull

        val tickets = moneyDistributionTicketRepository.findAll()
            .filter { it.status == NORMAL }
        assertThat(tickets.size).withFailMessage("NORMAL 티켓은 1개 줄어든 3개여야 한다.").isEqualTo(3)
        assertThat(tickets.sumOf { it.money }).withFailMessage("사용된 티켓 만큼 차감된 티켓들이 존재한다").isEqualTo(8500L)
    }

    @Sql("/data/money-distribution-completed.sql")
    @Test
    internal fun `정상 티켓이 모두 받아진 상태에서 받으려고 하면 예외가 발생한다`() {
        // GIVEN
        val userId = 2L
        val token = "a12"

        // WHEN
        assertThrows<DistributionDoneException> {
            moneyDistributionService.receiveMoney(userId, token)
        }
    }

    @Sql("/data/money-distribution-done.sql")
    @Test
    internal fun `받기 완료된 요청을 조회하면 분배 금액과 받은 금액 총합이 같다`() {
        // GIVEN
        val token = "a12"

        // WHEN
        val result = moneyDistributionService.getMoneyDistributionResult(token)

        // THEN
        assertThat(result.totalMoney).isEqualTo(10000L)
        assertThat(result.totalReceiptMoney).isEqualTo(8000L)
        assertThat(result.receiptDetailList.size).isEqualTo(3)
        assertThat(result.receiptDetailList.sumOf { it.receiptMoney }).isEqualTo(8000L)
    }

    @Sql("/data/money-distribution-old.sql")
    @Test
    internal fun `돈 분배한지 7일을 넘은 오래된 건에 대한 조회 요청은 실패한다`() {
        // GIVEN
        val token = "a12"

        assertThrows<SearchDisabledException> {
            // WHEN
            moneyDistributionService.getMoneyDistributionResult(token)
        }
    }
}
