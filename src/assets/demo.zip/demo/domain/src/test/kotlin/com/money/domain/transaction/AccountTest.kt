package com.money.domain.transaction

import com.money.common.util.orElseThrow
import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Test
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest
import org.springframework.test.context.jdbc.Sql

/**
 * @author traeper
 */
@DataJpaTest
class AccountTest {

    @Autowired
    private lateinit var accountRepository: AccountRepository

    @Sql("/data/account.sql")
    @Test
    internal fun `돈을 100만큼 넣으면 잔액이 100만큼 증가된다`() {
        val account = accountRepository.findById(1L).orElseThrow()
        account.addBalance(100L)
        accountRepository.save(account)

        val saved = accountRepository.findById(1L).orElseThrow()
        assertThat(saved.balance).withFailMessage("잔액이 100L만큼 증가해야 한다.").isEqualTo(10100L)
    }

    @Sql("/data/account.sql")
    @Test
    internal fun `돈을 100만큼 인출하면 잔액이 100만큼 감소된다`() {
        val account = accountRepository.findById(1L).orElseThrow()
        account.subtractBalance(100L)
        accountRepository.save(account)

        val saved = accountRepository.findById(1L).orElseThrow()
        assertThat(saved.balance).withFailMessage("잔액이 100L만큼 감소해야 한다.").isEqualTo(9900L)
    }
}
