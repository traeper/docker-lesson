INSERT INTO MoneyDistribution (moneyDistributionId, userId, totalMoney, distributionCount, status, canSearch, token, createdDateTime, insertDateTime, updateDateTime)
VALUES (1, 1, 10000, 4, 'NORMAL', true, 'a12', now(), now(), now());

INSERT INTO MoneyDistributionTicket (moneyDistributionTicketId, moneyDistributionId, money, status, createdDateTime, receiveCompletedDateTime, insertDateTime, updateDateTime)
VALUES (1, 1, 1500, 'NORMAL', now(), null, now(), now());

INSERT INTO MoneyDistributionTicket (moneyDistributionTicketId, moneyDistributionId, money, status, createdDateTime, receiveCompletedDateTime, insertDateTime, updateDateTime)
VALUES (2, 1, 3000, 'NORMAL', now(), null, now(), now());

INSERT INTO MoneyDistributionTicket (moneyDistributionTicketId, moneyDistributionId, money, status, createdDateTime, receiveCompletedDateTime, insertDateTime, updateDateTime)
VALUES (3, 1, 3500, 'NORMAL', now(), null, now(), now());

INSERT INTO MoneyDistributionTicket (moneyDistributionTicketId, moneyDistributionId, money, status, createdDateTime, receiveCompletedDateTime, insertDateTime, updateDateTime)
VALUES (4, 1, 2000, 'NORMAL', now(), null, now(), now());
