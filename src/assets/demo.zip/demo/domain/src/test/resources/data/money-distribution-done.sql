INSERT INTO MoneyDistribution (moneyDistributionId, userId, totalMoney, distributionCount, status, canSearch, token, createdDateTime, insertDateTime, updateDateTime)
VALUES (1, 1, 10000, 4, 'DONE', true, 'a12', now(), now(), now());

INSERT INTO MoneyDistributionTicket (moneyDistributionTicketId, moneyDistributionId, money, status, createdDateTime, receiveCompletedDateTime, insertDateTime, updateDateTime)
VALUES (1, 1, 1500, 'RECEIPT_COMPLETE', now(), null, now(), now());

INSERT INTO MoneyDistributionTicket (moneyDistributionTicketId, moneyDistributionId, money, status, createdDateTime, receiveCompletedDateTime, insertDateTime, updateDateTime)
VALUES (2, 1, 3000, 'RECEIPT_COMPLETE', now(), null, now(), now());

INSERT INTO MoneyDistributionTicket (moneyDistributionTicketId, moneyDistributionId, money, status, createdDateTime, receiveCompletedDateTime, insertDateTime, updateDateTime)
VALUES (3, 1, 3500, 'RECEIPT_COMPLETE', now(), null, now(), now());

INSERT INTO MoneyDistributionTicket (moneyDistributionTicketId, moneyDistributionId, money, status, createdDateTime, receiveCompletedDateTime, insertDateTime, updateDateTime)
VALUES (4, 1, 2000, 'CANCEL', now(), null, now(), now());

INSERT INTO MoneyDistributionTicketReceipt (moneyDistributionTicketReceiptId, userId, moneyDistributionId, moneyDistributionTicketId, money, createdDateTime, insertDateTime, updateDateTime)
VALUES (1, 2, 1, 1, 1500, now(), now(), now());

INSERT INTO MoneyDistributionTicketReceipt (moneyDistributionTicketReceiptId, userId, moneyDistributionId, moneyDistributionTicketId, money, createdDateTime, insertDateTime, updateDateTime)
VALUES (2, 3, 1, 2, 3000, now(), now(), now());

INSERT INTO MoneyDistributionTicketReceipt (moneyDistributionTicketReceiptId, userId, moneyDistributionId, moneyDistributionTicketId, money, createdDateTime, insertDateTime, updateDateTime)
VALUES (3, 4, 1, 3, 3500, now(), now(), now());

INSERT INTO User (userId, userName, insertDateTime, updateDateTime)
VALUES (1, 'user1', now(), now());

INSERT INTO User (userId, userName, insertDateTime, updateDateTime)
VALUES (2, 'user2', now(), now());

INSERT INTO User (userId, userName, insertDateTime, updateDateTime)
VALUES (3, 'user3', now(), now());

INSERT INTO User (userId, userName, insertDateTime, updateDateTime)
VALUES (4, 'user4', now(), now());