package com.money.domain.distribution.exception

/**
 * @author traeper
 */
class InvalidParameterException : RuntimeException {
    constructor() : super()
    constructor(message: String) : super(message)
}
