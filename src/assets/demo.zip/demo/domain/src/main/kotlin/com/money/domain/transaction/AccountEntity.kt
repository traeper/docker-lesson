package com.money.domain.transaction

import com.money.ddd.domain.AbstractSystemEntity
import com.money.ddd.domain.AggregateRoot
import com.money.ddd.jpa.checkPersisted
import javax.persistence.Column
import javax.persistence.Entity
import javax.persistence.GeneratedValue
import javax.persistence.GenerationType
import javax.persistence.Id
import javax.persistence.Index
import javax.persistence.Table

/**
 * @author traeper
 */
@Entity
@Table(
    name = "Account",
    indexes = [Index(unique = true, columnList = "userId")]
)
class AccountEntity(
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    val accountId: Long? = null,

    @Column(nullable = false)
    val userId: Long,

    @Column(nullable = false)
    var balance: Long
) : AbstractSystemEntity(), AggregateRoot<AccountEntity, Long> {
    override fun getId(): Long {
        return accountId.checkPersisted()
    }

    fun addBalance(money: Long) {
        balance += money
    }

    fun subtractBalance(money: Long) {
        balance -= money
    }

    companion object {
        fun create(
            userId: Long,
            initialBalance: Long
        ): AccountEntity {
            return AccountEntity(
                userId = userId,
                balance = initialBalance
            )
        }
    }
}
