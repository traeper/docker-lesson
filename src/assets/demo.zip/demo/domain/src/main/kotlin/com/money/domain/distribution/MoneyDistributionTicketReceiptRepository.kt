package com.money.domain.distribution

import org.springframework.data.jpa.repository.JpaRepository

interface MoneyDistributionTicketReceiptRepository : JpaRepository<MoneyDistributionTicketReceiptEntity, Long> {
    fun findByUserIdAndMoneyDistributionId(userId: Long, moneyDistributionId: Long): MoneyDistributionTicketReceiptEntity?

    fun findByMoneyDistributionId(moneyDistributionId: Long): List<MoneyDistributionTicketReceiptEntity>
}
