package com.money.domain.distribution.chat

import org.springframework.data.jpa.repository.JpaRepository

interface ChatRoomMoneyDistributionRepository : JpaRepository<ChatRoomMoneyDistributionEntity, Long> {
    fun findByMoneyDistributionId(moneyDistributionId: Long): ChatRoomMoneyDistributionEntity?
}
