package com.money.domain.distribution

import com.money.ddd.domain.AbstractSystemEntity
import com.money.ddd.domain.AggregateRoot
import com.money.ddd.jpa.checkPersisted
import com.money.domain.distribution.exception.InvalidParameterException
import java.time.ZonedDateTime
import javax.persistence.Column
import javax.persistence.Entity
import javax.persistence.EnumType
import javax.persistence.Enumerated
import javax.persistence.GeneratedValue
import javax.persistence.GenerationType
import javax.persistence.Id
import javax.persistence.Index
import javax.persistence.Table

/**
 * @author traeper
 */
@Entity
@Table(name = "MoneyDistribution", indexes = [Index(unique = true, columnList = "token")])
class MoneyDistributionEntity(
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    val moneyDistributionId: Long? = null,

    @Column(nullable = false)
    val userId: Long,

    @Column(nullable = false)
    val totalMoney: Long,

    @Column(nullable = false)
    val distributionCount: Int,

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    var status: MoneyDistributionStatus,

    @Column(nullable = false)
    var canSearch: Boolean,

    @Column(nullable = false)
    val token: String,

    @Column(nullable = false)
    val createdDateTime: ZonedDateTime
) : AbstractSystemEntity(), AggregateRoot<MoneyDistributionEntity, Long> {
    override fun getId(): Long {
        return moneyDistributionId.checkPersisted()
    }

    fun distribute(moneyDistributor: (totalMoney: Long, distributionCount: Int) -> List<Long>): List<Long> {
        return moneyDistributor.invoke(totalMoney, distributionCount)
    }

    fun isDone(): Boolean {
        if (status == MoneyDistributionStatus.DONE) {
            return true
        }

        val fromNow10Minutes = ZonedDateTime.now().minusMinutes(10L)
        if (createdDateTime.isBefore(fromNow10Minutes)) {
            return true
        }

        return false
    }

    fun canSearch(): Boolean {
        if (!canSearch) {
            return false
        }

        val fromNow7Days = ZonedDateTime.now().minusDays(7L)
        if (createdDateTime.isBefore(fromNow7Days)) {
            return false
        }
        return true
    }

    companion object {
        fun create(
            userId: Long,
            totalMoney: Long,
            distributionCount: Int,
            token: String
        ): MoneyDistributionEntity {
            if (userId <= 0) {
                throw InvalidParameterException("Invalid userId, $userId")
            }
            if (totalMoney <= 0) {
                throw InvalidParameterException("Invalid totalMoney, $totalMoney")
            }
            if (distributionCount <= 0) {
                throw InvalidParameterException("Invalid distributionCount, $distributionCount")
            }
            if (token.length != 3) {
                throw InvalidParameterException("Invalid Token Length, $token")
            }

            val now = ZonedDateTime.now()
            return MoneyDistributionEntity(
                userId = userId,
                totalMoney = totalMoney,
                distributionCount = distributionCount,
                status = MoneyDistributionStatus.NORMAL,
                canSearch = true,
                token = token,
                createdDateTime = now
            )
        }
    }
}
