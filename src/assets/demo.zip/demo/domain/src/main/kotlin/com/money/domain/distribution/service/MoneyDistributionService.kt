package com.money.domain.distribution.service

import com.money.common.util.orElseThrow
import com.money.ddd.domain.DomainService
import com.money.domain.distribution.MoneyDistributionEntity
import com.money.domain.distribution.MoneyDistributionRepository
import com.money.domain.distribution.MoneyDistributionTicketEntity
import com.money.domain.distribution.MoneyDistributionTicketReceiptEntity
import com.money.domain.distribution.MoneyDistributionTicketReceiptRepository
import com.money.domain.distribution.MoneyDistributionTicketRepository
import com.money.domain.distribution.TicketStatus
import com.money.domain.distribution.exception.DistributionDoneException
import com.money.domain.distribution.exception.SearchDisabledException
import com.money.domain.distribution.service.model.DistributionResult
import com.money.domain.distribution.service.model.ReceiptDetail
import com.money.domain.user.UserRepository
import org.springframework.transaction.annotation.Transactional
import java.time.ZonedDateTime

/**
 * MoneyDistribution related domain service
 * @author traeper
 */
@DomainService
class MoneyDistributionService(
    private val moneyDistributionRepository: MoneyDistributionRepository,
    private val moneyDistributionTicketRepository: MoneyDistributionTicketRepository,
    private val moneyDistributionTicketReceiptRepository: MoneyDistributionTicketReceiptRepository,
    private val userRepository: UserRepository
) {

    /**
     * 돈 분배하기
     * @return access token
     */
    @Transactional
    fun distributeMoney(
        userId: Long,
        totalMoney: Long,
        distributionCount: Int,
        token: String,
        numberDistributor: (totalMoney: Long, distributionCount: Int) -> List<Long>
    ): MoneyDistributionEntity {
        val distribution = moneyDistributionRepository.save(
            MoneyDistributionEntity.create(
                userId = userId,
                totalMoney = totalMoney,
                distributionCount = distributionCount,
                token = token
            )
        )

        val tickets = distribution.distribute(numberDistributor)
            .map { MoneyDistributionTicketEntity.create(distribution.getId(), it) }

        moneyDistributionTicketRepository.saveAll(tickets)

        return distribution
    }

    @Transactional
    fun receiveMoney(
        signedUserId: Long,
        token: String
    ): MoneyDistributionTicketEntity {
        val distribution = moneyDistributionRepository.findByToken(token).orElseThrow()
        if (distribution.isDone()) {
            throw DistributionDoneException()
        }

        val ticket = moneyDistributionTicketRepository.findTopByMoneyDistributionIdAndStatusOrderByMoneyDistributionTicketId(
            moneyDistributionId = distribution.getId(),
            status = TicketStatus.NORMAL
        ).orElseThrow(DistributionDoneException())

        // 정상 티켓 사용
        val result = moneyDistributionTicketRepository.useTicket(ticket.getId(), ZonedDateTime.now())
        if (result == 0) {
            throw RuntimeException("동시성 이슈로 인해 실패")
        }

        // 티켓 영수증 생성
        moneyDistributionTicketReceiptRepository.save(
            MoneyDistributionTicketReceiptEntity.create(
                userId = signedUserId,
                moneyDistributionId = distribution.getId(),
                moneyDistributionTicketId = ticket.getId(),
                money = ticket.money
            )
        )

        return moneyDistributionTicketRepository.findById(ticket.getId()).orElseThrow()
    }

    fun getMoneyDistributionResult(token: String): DistributionResult {
        val distribution = moneyDistributionRepository.findByToken(token).orElseThrow()
        if (!distribution.canSearch()) {
            throw SearchDisabledException()
        }

        val ticketReceipts = moneyDistributionTicketReceiptRepository.findByMoneyDistributionId(distribution.getId())

        val userIdMap = userRepository.findByUserIdIn(ticketReceipts.map { it.userId })
            .map { it.getId() to it }
            .toMap()

        return DistributionResult(
            distributionDateTime = distribution.createdDateTime,
            totalMoney = distribution.totalMoney,
            totalReceiptMoney = ticketReceipts.sumOf { it.money },
            receiptDetailList = ticketReceipts
                .map { ReceiptDetail(it.userId, userIdMap[it.userId]?.userName ?: error(""), it.money) }
        )
    }
}
