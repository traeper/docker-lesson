package com.money.domain.distribution.exception

/**
 * @author traeper
 */
class SearchDisabledException : RuntimeException()
