package com.money.domain.chat

import org.springframework.data.jpa.repository.JpaRepository
import java.util.UUID

interface ChatRoomUserRepository : JpaRepository<ChatRoomUserEntity, Long> {
    fun findByChatRoomIdAndUserId(chatRoomId: UUID, userId: Long): ChatRoomUserEntity?

    fun findByChatRoomId(chatRoomId: UUID): List<ChatRoomUserEntity>
}
