package com.money.domain.distribution

/**
 * @property NORMAL 정상 생성
 * @property RECEIPT_COMPLETE 수령 완료
 * @property CANCEL 취소 - 배치에서 처리
 * @author traeper
 */
enum class TicketStatus {
    NORMAL,
    RECEIPT_COMPLETE,
    CANCEL
}
