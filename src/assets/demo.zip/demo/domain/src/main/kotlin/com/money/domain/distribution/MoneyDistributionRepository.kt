package com.money.domain.distribution

import org.springframework.data.domain.Page
import org.springframework.data.domain.Pageable
import org.springframework.data.jpa.repository.JpaRepository
import java.time.ZonedDateTime

interface MoneyDistributionRepository : JpaRepository<MoneyDistributionEntity, Long> {

    fun findByToken(token: String): MoneyDistributionEntity?

    fun findByStatusAndCreatedDateTimeBefore(status: MoneyDistributionStatus, before: ZonedDateTime, pageable: Pageable): Page<MoneyDistributionEntity>

    fun findByCanSearchAndCreatedDateTimeBefore(canSearch: Boolean, before: ZonedDateTime, pageable: Pageable): Page<MoneyDistributionEntity>
}
