package com.money.domain.distribution

import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.data.jpa.repository.Modifying
import org.springframework.data.jpa.repository.Query
import java.time.ZonedDateTime

interface MoneyDistributionTicketRepository : JpaRepository<MoneyDistributionTicketEntity, Long> {
    fun findTopByMoneyDistributionIdAndStatusOrderByMoneyDistributionTicketId(moneyDistributionId: Long, status: TicketStatus): MoneyDistributionTicketEntity?

    // Update Lock
    @Modifying(flushAutomatically = true, clearAutomatically = true)
    @Query(
        """UPDATE MoneyDistributionTicketEntity e    
        SET e.status = 'RECEIPT_COMPLETE', e.receiveCompletedDateTime = :receiveCompletedDateTime       
        WHERE e.moneyDistributionTicketId = :moneyDistributionTicketId and e.status = 'NORMAL'
        """
    )
    fun useTicket(moneyDistributionTicketId: Long, receiveCompletedDateTime: ZonedDateTime): Int
}
