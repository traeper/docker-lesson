package com.money.domain.distribution.chat

import com.money.ddd.domain.AbstractSystemEntity
import java.util.UUID
import javax.persistence.Column
import javax.persistence.Entity
import javax.persistence.GeneratedValue
import javax.persistence.GenerationType
import javax.persistence.Id
import javax.persistence.Table

/**
 * @author traeper
 */
@Entity
@Table(name = "ChatRoomMoneyDistribution")
class ChatRoomMoneyDistributionEntity(
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    val chatRoomMoneyDistributionId: Long? = null,

    @Column(nullable = false)
    val chatRoomId: UUID,

    @Column(nullable = false)
    val moneyDistributionId: Long
) : AbstractSystemEntity() {
    companion object {
        fun create(
            chatRoomId: UUID,
            moneyDistributionId: Long
        ): ChatRoomMoneyDistributionEntity {
            return ChatRoomMoneyDistributionEntity(
                chatRoomId = chatRoomId,
                moneyDistributionId = moneyDistributionId
            )
        }
    }
}
