package com.money.domain.distribution

import com.money.ddd.domain.AbstractSystemEntity
import com.money.ddd.domain.AggregateRoot
import com.money.ddd.jpa.checkPersisted
import java.time.ZonedDateTime
import javax.persistence.Column
import javax.persistence.Entity
import javax.persistence.EnumType
import javax.persistence.Enumerated
import javax.persistence.GeneratedValue
import javax.persistence.GenerationType
import javax.persistence.Id
import javax.persistence.Table

/**
 * @author traeper
 */
@Entity
@Table(name = "MoneyDistributionTicket")
class MoneyDistributionTicketEntity(
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    val moneyDistributionTicketId: Long? = null,

    @Column(nullable = false)
    val moneyDistributionId: Long,

    @Column(nullable = false)
    val money: Long,

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    var status: TicketStatus,

    @Column(nullable = false)
    val createdDateTime: ZonedDateTime,

    @Column
    var receiveCompletedDateTime: ZonedDateTime? = null
) : AbstractSystemEntity(), AggregateRoot<MoneyDistributionTicketEntity, Long> {
    override fun getId(): Long {
        return moneyDistributionTicketId.checkPersisted()
    }

    companion object {
        fun create(
            moneyDistributionId: Long,
            money: Long
        ): MoneyDistributionTicketEntity {
            return MoneyDistributionTicketEntity(
                moneyDistributionId = moneyDistributionId,
                money = money,
                status = TicketStatus.NORMAL,
                createdDateTime = ZonedDateTime.now()
            )
        }
    }
}
