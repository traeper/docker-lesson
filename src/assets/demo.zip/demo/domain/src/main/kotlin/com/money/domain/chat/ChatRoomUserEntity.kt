package com.money.domain.chat

import com.money.ddd.domain.AbstractSystemEntity
import java.util.UUID
import javax.persistence.Column
import javax.persistence.Entity
import javax.persistence.GeneratedValue
import javax.persistence.GenerationType
import javax.persistence.Id
import javax.persistence.Table

/**
 * @author traeper
 */
@Entity
@Table(name = "ChatRoomUser")
class ChatRoomUserEntity(
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    val chatRoomUserId: Long? = null,

    @Column(nullable = false)
    val chatRoomId: UUID,

    @Column(nullable = false)
    val userId: Long
) : AbstractSystemEntity()
