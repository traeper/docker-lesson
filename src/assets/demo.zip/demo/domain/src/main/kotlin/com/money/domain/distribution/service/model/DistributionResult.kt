package com.money.domain.distribution.service.model

import java.time.ZonedDateTime

/**
 * @author traeper
 */
data class DistributionResult(
    val distributionDateTime: ZonedDateTime,
    val totalMoney: Long,
    val totalReceiptMoney: Long,
    val receiptDetailList: List<ReceiptDetail>
)

data class ReceiptDetail(
    val userId: Long,
    val userName: String,
    val receiptMoney: Long
)
