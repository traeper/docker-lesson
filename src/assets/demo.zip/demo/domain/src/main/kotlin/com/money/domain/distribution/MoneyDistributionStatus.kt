package com.money.domain.distribution

/**
 * @author traeper
 */
enum class MoneyDistributionStatus {
    NORMAL,
    DONE
}
