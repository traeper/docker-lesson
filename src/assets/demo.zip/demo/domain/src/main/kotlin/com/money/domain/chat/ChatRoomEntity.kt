package com.money.domain.chat

import com.money.ddd.domain.AbstractSystemEntity
import com.money.ddd.domain.AggregateRoot
import com.money.ddd.jpa.checkPersisted
import org.hibernate.annotations.GenericGenerator
import java.util.UUID
import javax.persistence.Column
import javax.persistence.Entity
import javax.persistence.GeneratedValue
import javax.persistence.Id
import javax.persistence.Table

/**
 * @author traeper
 */
@Entity
@Table(name = "ChatRoom")
class ChatRoomEntity(
    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(columnDefinition = "BINARY(16)")
    val chatRoomId: UUID? = null
) : AbstractSystemEntity(), AggregateRoot<ChatRoomEntity, UUID> {
    override fun getId(): UUID {
        return chatRoomId.checkPersisted()
    }
}
