package com.money.domain.transaction

import org.springframework.data.jpa.repository.JpaRepository

interface AccountRepository : JpaRepository<AccountEntity, Long> {

    fun findByUserId(userId: Long): AccountEntity
}
