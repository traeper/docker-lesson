package com.money.domain.user

import com.money.ddd.domain.AbstractSystemEntity
import com.money.ddd.domain.AggregateRoot
import com.money.ddd.jpa.checkPersisted
import javax.persistence.Column
import javax.persistence.Entity
import javax.persistence.GeneratedValue
import javax.persistence.GenerationType
import javax.persistence.Id
import javax.persistence.Table

/**
 * @author traeper
 */
@Entity
@Table(name = "User")
class UserEntity(
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    val userId: Long? = null,

    // 사용자 아이디
    @Column(nullable = false)
    val userName: String
) : AbstractSystemEntity(), AggregateRoot<UserEntity, Long> {
    override fun getId(): Long {
        return userId.checkPersisted()
    }
}
