package com.money.domain.distribution

import com.money.ddd.domain.AbstractSystemEntity
import com.money.ddd.domain.AggregateRoot
import com.money.ddd.jpa.checkPersisted
import java.time.ZonedDateTime
import javax.persistence.Column
import javax.persistence.Entity
import javax.persistence.GeneratedValue
import javax.persistence.GenerationType
import javax.persistence.Id
import javax.persistence.Index
import javax.persistence.Table

/**
 * @author traeper
 */
@Entity
@Table(
    name = "MoneyDistributionTicketReceipt",
    indexes = [Index(unique = true, columnList = "userId,moneyDistributionId")] // 유니크 인덱스로 중복 insert 방지
)
class MoneyDistributionTicketReceiptEntity(
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    val moneyDistributionTicketReceiptId: Long? = null,

    @Column(nullable = false)
    val userId: Long,

    @Column(nullable = false)
    val moneyDistributionId: Long,

    @Column(nullable = false)
    val moneyDistributionTicketId: Long,

    // ticket과 반정규화
    @Column(nullable = false)
    val money: Long,

    @Column(nullable = false)
    val createdDateTime: ZonedDateTime
) : AbstractSystemEntity(), AggregateRoot<MoneyDistributionTicketReceiptEntity, Long> {
    override fun getId(): Long {
        return moneyDistributionTicketReceiptId.checkPersisted()
    }

    companion object {
        fun create(
            userId: Long,
            moneyDistributionId: Long,
            moneyDistributionTicketId: Long,
            money: Long
        ): MoneyDistributionTicketReceiptEntity {
            return MoneyDistributionTicketReceiptEntity(
                userId = userId,
                moneyDistributionId = moneyDistributionId,
                moneyDistributionTicketId = moneyDistributionTicketId,
                money = money,
                createdDateTime = ZonedDateTime.now()
            )
        }
    }
}
