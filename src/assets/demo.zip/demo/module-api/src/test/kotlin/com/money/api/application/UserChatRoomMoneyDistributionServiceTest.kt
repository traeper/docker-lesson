package com.money.api.application

import com.money.api.exception.ChatRoomInsufficientUsersException
import com.money.domain.distribution.MoneyDistributionTicketRepository
import com.money.domain.distribution.TicketStatus.NORMAL
import com.money.domain.distribution.exception.DistributionDoneException
import com.money.domain.distribution.exception.SearchDisabledException
import org.assertj.core.api.Assertions
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.assertThrows
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.test.context.jdbc.Sql
import org.springframework.transaction.annotation.Transactional
import java.util.UUID

/**
 * @author traeper
 */
@SpringBootTest
@Transactional
class UserChatRoomMoneyDistributionServiceTest {

    @Autowired
    private lateinit var userChatRoomMoneyDistributionService: UserChatRoomMoneyDistributionService

    @Autowired
    private lateinit var moneyDistributionTicketRepository: MoneyDistributionTicketRepository

    @Sql("/data/base.sql")
    @Test
    internal fun `돈을분배할 때 채팅방에 분배자를 제외한 인원수보다 많으면 예외가 발생한다`() {
        // GIVEN
        val userId = 1L
        val totalMoney = 10000L
        val distributionCount = 5
        val chatRoomId = UUID.fromString("27499D20-2C1D-11EB-A22C-828D3F9221EA")

        // THEN
        assertThrows<ChatRoomInsufficientUsersException> {
            // WHEN
            userChatRoomMoneyDistributionService.distributeMoney(
                userId = userId,
                chatRoomId = chatRoomId,
                totalMoney = totalMoney,
                distributionCount = distributionCount
            )
        }
    }

    @Sql("/data/base.sql")
    @Test
    internal fun `돈을 분배하면 원하는 갯수만큼 분배되며 합은 totalMoney와 같다`() {
        // GIVEN
        val userId = 1L
        val totalMoney = 10000L
        val distributionCount = 2
        val chatRoomId = UUID.fromString("27499D20-2C1D-11EB-A22C-828D3F9221EA")

        // WHEN
        val token = userChatRoomMoneyDistributionService.distributeMoney(
            userId = userId,
            chatRoomId = chatRoomId,
            totalMoney = totalMoney,
            distributionCount = distributionCount
        )

        // THEN
        Assertions.assertThat(token.length).withFailMessage("token은 TokenGenerator 구현체 스팩을 따라야 한다.").isEqualTo(3)

        val tickets = moneyDistributionTicketRepository.findAll()
        Assertions.assertThat(tickets.size).withFailMessage("원하는 갯수만큼 분배되어야 한다").isEqualTo(distributionCount)
        Assertions.assertThat(tickets.sumOf { it.money }).withFailMessage("분배된 모든 티켓의 돈 총합은 totalMoney와 같아야 한다").isEqualTo(totalMoney)
    }

    @Sql(value = ["/data/base.sql", "/data/money-distribution-done.sql"])
    @Test
    internal fun `돈 분배 완료된 건에 대한 받기 요청은 실패한다`() {
        // GIVEN
        val userId = 1L
        val token = "a12"

        assertThrows<DistributionDoneException> {
            // WHEN
            userChatRoomMoneyDistributionService.receiveMoney(userId, token)
        }
    }

    @Sql(value = ["/data/base.sql", "/data/money-distribution-old.sql"])
    @Test
    internal fun `돈 분배한지 10분 지난 건에 대한 받기 요청은 실패한다`() {
        // GIVEN
        val userId = 1L
        val token = "a12"

        assertThrows<DistributionDoneException> {
            // WHEN
            userChatRoomMoneyDistributionService.receiveMoney(userId, token)
        }
    }

    @Sql(value = ["/data/base.sql", "/data/money-distribution.sql"])
    @Test
    internal fun `분배된 머니 티켓 첫 번째 티켓을 받는다`() {
        // GIVEN
        val userId = 1L
        val token = "a12"

        // WHEN
        val money = userChatRoomMoneyDistributionService.receiveMoney(userId, token)

        // THEN
        Assertions.assertThat(money).isEqualTo(1500L)

        val tickets = moneyDistributionTicketRepository.findAll()
            .filter { it.status == NORMAL }
        Assertions.assertThat(tickets.size).withFailMessage("NORMAL 티켓은 1개 줄어든 3개여야 한다.").isEqualTo(3)
        Assertions.assertThat(tickets.sumOf { it.money }).withFailMessage("사용된 티켓 만큼 차감된 티켓들이 존재한다").isEqualTo(8500L)
    }

    @Sql("/data/money-distribution-old.sql")
    @Test
    internal fun `돈 분배한지 7일을 넘은 오래된 건에 대한 조회 요청은 실패한다`() {
        // GIVEN
        val token = "a12"

        assertThrows<SearchDisabledException> {
            // WHEN
            userChatRoomMoneyDistributionService.getMoneyDistributionResult(token)
        }
    }
}
