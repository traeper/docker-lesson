package com.money.api.presentation

import com.fasterxml.jackson.databind.ObjectMapper
import com.money.api.presentation.model.ReceiptDetailResponse
import com.money.api.presentation.model.distribution.MoneyDistributionRequest
import org.hamcrest.Matchers.hasSize
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.extension.ExtendWith
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.http.MediaType
import org.springframework.test.context.jdbc.Sql
import org.springframework.test.context.junit.jupiter.SpringExtension
import org.springframework.test.web.servlet.MockMvc
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders
import org.springframework.test.web.servlet.result.MockMvcResultHandlers
import org.springframework.test.web.servlet.result.MockMvcResultMatchers
import org.springframework.transaction.annotation.Transactional
import java.util.UUID

/**
 * @author traeper
 */
@ExtendWith(SpringExtension::class)
@SpringBootTest
@AutoConfigureMockMvc
@Transactional
class MoneyDistributionControllerTest {

    @Autowired
    private lateinit var mockMvc: MockMvc

    @Autowired
    private lateinit var objectMapper: ObjectMapper

    @Sql("/data/base.sql")
    @Test
    internal fun `돈을분배할 때 채팅방에 분배자를 제외한 인원수보다 많으면 CHAT_ROOM_INSUFFICIENT_USERS가 발생한다`() {
        // GIVEN
        val userId = 1L
        val totalMoney = 10000L
        val distributionCount = 5
        val chatRoomId = UUID.fromString("27499D20-2C1D-11EB-A22C-828D3F9221EA")

        val request = MoneyDistributionRequest(totalMoney, distributionCount)

        val requestBuilder =
            MockMvcRequestBuilders.post("/v1/moneyDistributions")
                .header("X-USER-ID", userId)
                .header("X-ROOM-ID", chatRoomId)
                .content(objectMapper.writeValueAsString(request))
                .contentType(MediaType.APPLICATION_JSON)

        mockMvc.perform(requestBuilder)
            .andExpect(MockMvcResultMatchers.status().isForbidden)
            .andExpect(MockMvcResultMatchers.jsonPath("$.isSuccess").value(false))
            .andExpect(MockMvcResultMatchers.jsonPath("$.code").value("CHAT_ROOM_INSUFFICIENT_USERS"))
            .andDo(MockMvcResultHandlers.print())
    }

    @Sql("/data/base.sql")
    @Test
    fun `돈을 분배하면 길이 3인 토큰이 리턴된다`() {
        // GIVEN
        val userId = 1L
        val totalMoney = 10000L
        val distributionCount = 2
        val chatRoomId = UUID.fromString("27499D20-2C1D-11EB-A22C-828D3F9221EA")

        val request = MoneyDistributionRequest(totalMoney, distributionCount)

        val requestBuilder =
            MockMvcRequestBuilders.post("/v1/moneyDistributions")
                .header("X-USER-ID", userId)
                .header("X-ROOM-ID", chatRoomId)
                .content(objectMapper.writeValueAsString(request))
                .contentType(MediaType.APPLICATION_JSON)

        mockMvc.perform(requestBuilder)
            .andExpect(MockMvcResultMatchers.status().isOk)
            .andExpect(MockMvcResultMatchers.jsonPath("$.isSuccess").value(true))
            .andExpect(MockMvcResultMatchers.jsonPath("$.code").value("SUCCESS"))
            .andDo(MockMvcResultHandlers.print())
    }

    @Sql(value = ["/data/base.sql", "/data/money-distribution-old.sql"])
    @Test
    internal fun `돈 분배한지 7일을 넘은 오래된 건에 대한 조회 요청은 실패한다`() {
        // GIVEN
        val userId = 1L
        val token = "a12"
        val requestBuilder =
            MockMvcRequestBuilders.get("/v1/moneyDistributions/$token")
                .header("X-USER-ID", userId)

        mockMvc.perform(requestBuilder)
            .andExpect(MockMvcResultMatchers.status().isForbidden)
            .andExpect(MockMvcResultMatchers.jsonPath("$.isSuccess").value(false))
            .andExpect(MockMvcResultMatchers.jsonPath("$.code").value("SEARCH_DISABLED"))
            .andDo(MockMvcResultHandlers.print())
    }

    @Sql(value = ["/data/base.sql", "/data/money-distribution-done.sql"])
    @Test
    internal fun `타인의 분배건을 조회하면 403 HTTP Status와 함께 FORBIDDEN 코드가 내려온다`() {
        // GIVEN
        val userId = 2L
        val token = "a12"
        val requestBuilder =
            MockMvcRequestBuilders.get("/v1/moneyDistributions/$token")
                .header("X-USER-ID", userId)

        mockMvc.perform(requestBuilder)
            .andExpect(MockMvcResultMatchers.status().isForbidden)
            .andExpect(MockMvcResultMatchers.jsonPath("$.isSuccess").value(false))
            .andExpect(MockMvcResultMatchers.jsonPath("$.code").value("FORBIDDEN"))
            .andDo(MockMvcResultHandlers.print())
    }

    @Sql(value = ["/data/base.sql", "/data/money-distribution.sql"])
    @Test
    internal fun `존재하지 않는 토큰으로 조회하면 403 HTTP Status와 함께 FORBIDDEN 코드가 내려온다`() {
        // GIVEN
        val userId = 2L
        val token = "a99"
        val requestBuilder =
            MockMvcRequestBuilders.get("/v1/moneyDistributions/$token")
                .header("X-USER-ID", userId)

        mockMvc.perform(requestBuilder)
            .andExpect(MockMvcResultMatchers.status().isForbidden)
            .andExpect(MockMvcResultMatchers.jsonPath("$.isSuccess").value(false))
            .andExpect(MockMvcResultMatchers.jsonPath("$.code").value("FORBIDDEN"))
            .andDo(MockMvcResultHandlers.print())
    }

    @Sql(value = ["/data/base.sql", "/data/money-distribution-done.sql"])
    @Test
    internal fun `받기 완료된 요청을 조회하면 분배 금액과 받은 금액 총합이 같다`() {
        // GIVEN
        val userId = 1L
        val token = "a12"
        val requestBuilder =
            MockMvcRequestBuilders.get("/v1/moneyDistributions/$token")
                .header("X-USER-ID", userId)

        mockMvc.perform(requestBuilder)
            .andExpect(MockMvcResultMatchers.status().isOk)
            .andExpect(MockMvcResultMatchers.jsonPath("$.isSuccess").value(true))
            .andExpect(MockMvcResultMatchers.jsonPath("$.code").value("SUCCESS"))
            .andExpect(MockMvcResultMatchers.jsonPath("$.data.totalMoney").value(10000L))
            .andExpect(MockMvcResultMatchers.jsonPath("$.data.totalReceiptMoney").value(8000L))
            .andExpect(MockMvcResultMatchers.jsonPath("$.data.receiptDetailResponseList", hasSize<List<ReceiptDetailResponse>>(3)))
            .andDo(MockMvcResultHandlers.print())
    }

    @Sql(value = ["/data/base.sql", "/data/money-distribution.sql"])
    @Test
    internal fun `존재하지 않는 토큰으로 받으면 403 HTTP Status와 함께 FORBIDDEN 코드가 내려온다`() {
        // GIVEN
        val userId = 2L
        val token = "a99"
        val requestBuilder =
            MockMvcRequestBuilders.get("/v1/moneyDistributions/$token/receive")
                .header("X-USER-ID", userId)

        mockMvc.perform(requestBuilder)
            .andExpect(MockMvcResultMatchers.status().isForbidden)
            .andExpect(MockMvcResultMatchers.jsonPath("$.isSuccess").value(false))
            .andExpect(MockMvcResultMatchers.jsonPath("$.code").value("FORBIDDEN"))
            .andDo(MockMvcResultHandlers.print())
    }

    @Sql(value = ["/data/base.sql", "/data/money-distribution.sql"])
    @Test
    internal fun `내가 분배한 돈을 받으려하면 403 HTTP Status와 함께 RECEIVE_OWN_MONEY 코드가 내려온다`() {
        // GIVEN
        val userId = 1L
        val token = "a12"
        val requestBuilder =
            MockMvcRequestBuilders.get("/v1/moneyDistributions/$token/receive")
                .header("X-USER-ID", userId)

        mockMvc.perform(requestBuilder)
            .andExpect(MockMvcResultMatchers.status().isForbidden)
            .andExpect(MockMvcResultMatchers.jsonPath("$.isSuccess").value(false))
            .andExpect(MockMvcResultMatchers.jsonPath("$.code").value("RECEIVE_OWN_MONEY"))
            .andDo(MockMvcResultHandlers.print())
    }

    @Sql(value = ["/data/base.sql", "/data/money-distribution-old.sql"])
    @Test
    internal fun `오래된 분배건을 받으려하면 403 HTTP Status와 함께 DISTRIBUTION_DONE 코드가 내려온다`() {
        // GIVEN
        val userId = 2L
        val token = "a12"
        val requestBuilder =
            MockMvcRequestBuilders.get("/v1/moneyDistributions/$token/receive")
                .header("X-USER-ID", userId)

        mockMvc.perform(requestBuilder)
            .andExpect(MockMvcResultMatchers.status().isForbidden)
            .andExpect(MockMvcResultMatchers.jsonPath("$.isSuccess").value(false))
            .andExpect(MockMvcResultMatchers.jsonPath("$.code").value("DISTRIBUTION_DONE"))
            .andDo(MockMvcResultHandlers.print())
    }

    @Sql(value = ["/data/base.sql", "/data/money-distribution-done.sql"])
    @Test
    internal fun `이미 받은 분배건을 다시 받으려하면 403 HTTP Status와 함께 ALREADY_RECEIVED_MONEY 코드가 내려온다`() {
        // GIVEN
        val userId = 2L
        val token = "a12"
        val requestBuilder =
            MockMvcRequestBuilders.get("/v1/moneyDistributions/$token/receive")
                .header("X-USER-ID", userId)

        mockMvc.perform(requestBuilder)
            .andExpect(MockMvcResultMatchers.status().isForbidden)
            .andExpect(MockMvcResultMatchers.jsonPath("$.isSuccess").value(false))
            .andExpect(MockMvcResultMatchers.jsonPath("$.code").value("ALREADY_RECEIVED_MONEY"))
            .andDo(MockMvcResultHandlers.print())
    }

    @Sql(value = ["/data/base.sql", "/data/money-distribution.sql"])
    @Test
    internal fun `권한이 허용되는 사용자는 돈을 정상적으로 받는다`() {
        // GIVEN
        val userId = 2L
        val token = "a12"
        val requestBuilder =
            MockMvcRequestBuilders.get("/v1/moneyDistributions/$token/receive")
                .header("X-USER-ID", userId)

        mockMvc.perform(requestBuilder)
            .andExpect(MockMvcResultMatchers.status().isOk)
            .andExpect(MockMvcResultMatchers.jsonPath("$.isSuccess").value(true))
            .andExpect(MockMvcResultMatchers.jsonPath("$.code").value("SUCCESS"))
            .andExpect(MockMvcResultMatchers.jsonPath("$.data").value(1500L))
            .andDo(MockMvcResultHandlers.print())
    }
}
