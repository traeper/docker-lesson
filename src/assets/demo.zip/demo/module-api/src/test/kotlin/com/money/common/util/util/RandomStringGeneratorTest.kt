package com.money.common.util.util

import com.money.common.util.RandomStringGenerator
import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Test

/**
 * @author traeper
 */
class RandomStringGeneratorTest {
    @Test
    internal fun `길이 3 문자열이 정상 생성된다`() {
        val generated = RandomStringGenerator.generate(3)
        assertThat(generated.length).isEqualTo(3)
    }
}
