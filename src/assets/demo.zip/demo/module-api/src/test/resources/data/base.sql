INSERT INTO User (userId, userName, insertDateTime, updateDateTime) VALUES (1, 'user1', now(), now());
INSERT INTO User (userId, userName, insertDateTime, updateDateTime) VALUES (2, 'user2', now(), now());
INSERT INTO User (userId, userName, insertDateTime, updateDateTime) VALUES (3, 'user3', now(), now());
INSERT INTO User (userId, userName, insertDateTime, updateDateTime) VALUES (4, 'user4', now(), now());

INSERT INTO Account (accountId, userId, balance, insertDateTime, updateDateTime) VALUES (1, 1, 1000000, now(), now());
INSERT INTO Account (accountId, userId, balance, insertDateTime, updateDateTime) VALUES (2, 2, 1000000, now(), now());
INSERT INTO Account (accountId, userId, balance, insertDateTime, updateDateTime) VALUES (3, 3, 1000000, now(), now());
INSERT INTO Account (accountId, userId, balance, insertDateTime, updateDateTime) VALUES (4, 4, 1000000, now(), now());

INSERT INTO ChatRoom (chatRoomId, insertDateTime, updateDateTime)
VALUES (x'27499D202C1D11EBA22C828D3F9221EA', now(), now());

INSERT INTO ChatRoomUser (chatRoomUserId, chatRoomId, userId, insertDateTime, updateDateTime)
VALUES (1, x'27499D202C1D11EBA22C828D3F9221EA', 1, now(), now());
INSERT INTO ChatRoomUser (chatRoomUserId, chatRoomId, userId, insertDateTime, updateDateTime)
VALUES (2, x'27499D202C1D11EBA22C828D3F9221EA', 2, now(), now());
INSERT INTO ChatRoomUser (chatRoomUserId, chatRoomId, userId, insertDateTime, updateDateTime)
VALUES (3, x'27499D202C1D11EBA22C828D3F9221EA', 3, now(), now());
INSERT INTO ChatRoomUser (chatRoomUserId, chatRoomId, userId, insertDateTime, updateDateTime)
VALUES (4, x'27499D202C1D11EBA22C828D3F9221EA', 4, now(), now());

