INSERT INTO Account (accountId, userId, balance, insertDateTime, updateDateTime)
VALUES (1, 1, 10000, now(), now());
