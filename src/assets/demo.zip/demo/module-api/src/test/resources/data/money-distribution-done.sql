INSERT INTO MoneyDistribution (moneyDistributionId, userId, totalMoney, distributionCount, status, canSearch, token, createdDateTime, insertDateTime, updateDateTime)
VALUES (1, 1, 10000, 4, 'DONE', true, 'a12', now(), now(), now());

INSERT INTO ChatRoomMoneyDistribution (chatRoomMoneyDistributionId, chatRoomId, moneyDistributionId, insertDateTime, updateDateTime)
VALUES (1, x'27499D202C1D11EBA22C828D3F9221EA', 1, now(), now());

INSERT INTO MoneyDistributionTicket (moneyDistributionTicketId, moneyDistributionId, money, status, createdDateTime, receiveCompletedDateTime, insertDateTime, updateDateTime)
VALUES (1, 1, 1500, 'RECEIPT_COMPLETE', now(), null, now(), now());

INSERT INTO MoneyDistributionTicket (moneyDistributionTicketId, moneyDistributionId, money, status, createdDateTime, receiveCompletedDateTime, insertDateTime, updateDateTime)
VALUES (2, 1, 3000, 'RECEIPT_COMPLETE', now(), null, now(), now());

INSERT INTO MoneyDistributionTicket (moneyDistributionTicketId, moneyDistributionId, money, status, createdDateTime, receiveCompletedDateTime, insertDateTime, updateDateTime)
VALUES (3, 1, 3500, 'RECEIPT_COMPLETE', now(), null, now(), now());

INSERT INTO MoneyDistributionTicket (moneyDistributionTicketId, moneyDistributionId, money, status, createdDateTime, receiveCompletedDateTime, insertDateTime, updateDateTime)
VALUES (4, 1, 2000, 'CANCEL', now(), null, now(), now());

INSERT INTO MoneyDistributionTicketReceipt (moneyDistributionTicketReceiptId, userId, moneyDistributionId, moneyDistributionTicketId, money, createdDateTime, insertDateTime, updateDateTime)
VALUES (1, 2, 1, 1, 1500, now(), now(), now());

INSERT INTO MoneyDistributionTicketReceipt (moneyDistributionTicketReceiptId, userId, moneyDistributionId, moneyDistributionTicketId, money, createdDateTime, insertDateTime, updateDateTime)
VALUES (2, 3, 1, 2, 3000, now(), now(), now());

INSERT INTO MoneyDistributionTicketReceipt (moneyDistributionTicketReceiptId, userId, moneyDistributionId, moneyDistributionTicketId, money, createdDateTime, insertDateTime, updateDateTime)
VALUES (3, 4, 1, 3, 3500, now(), now(), now());