drop table if exists Account;
drop table if exists ChatRoom;
drop table if exists ChatRoomMoneyDistribution;
drop table if exists ChatRoomUser;
drop table if exists MoneyDistribution;
drop table if exists MoneyDistributionTicket;
drop table if exists MoneyDistributionTicketReceipt;
drop table if exists User;

create table Account
(
    accountId      int(11)   NOT NULL AUTO_INCREMENT,
    insertDateTime timestamp not null,
    updateDateTime timestamp not null,
    balance        bigint    not null,
    userId         bigint    not null,
    primary key (accountId)
);

create table ChatRoom
(
    chatRoomId     BINARY(16) not null,
    insertDateTime timestamp  not null,
    updateDateTime timestamp  not null,
    primary key (chatRoomId)
);

create table ChatRoomMoneyDistribution
(
    chatRoomMoneyDistributionId int(11)   NOT NULL AUTO_INCREMENT,
    insertDateTime              timestamp not null,
    updateDateTime              timestamp not null,
    chatRoomId                  binary    not null,
    moneyDistributionId         bigint    not null,
    primary key (chatRoomMoneyDistributionId)
);

create table ChatRoomUser
(
    chatRoomUserId int(11)   NOT NULL AUTO_INCREMENT,
    insertDateTime timestamp not null,
    updateDateTime timestamp not null,
    chatRoomId     bigint    not null,
    userId         bigint    not null,
    primary key (chatRoomUserId)
);

create table MoneyDistribution
(
    moneyDistributionId int(11)      NOT NULL AUTO_INCREMENT,
    insertDateTime      timestamp    not null,
    updateDateTime      timestamp    not null,
    createdDateTime     timestamp    not null,
    distributionCount   integer      not null,
    status              varchar(255) not null,
    canSearch           tinyint(1)   not null,
    token               varchar(255) not null,
    totalMoney          bigint       not null,
    userId              bigint       not null,
    primary key (moneyDistributionId)
);

create table MoneyDistributionTicket
(
    moneyDistributionTicketId int(11)      NOT NULL AUTO_INCREMENT,
    insertDateTime            timestamp    not null,
    updateDateTime            timestamp    not null,
    createdDateTime           timestamp    not null,
    money                     bigint       not null,
    moneyDistributionId       bigint       not null,
    receiveCompletedDateTime  timestamp,
    status                    varchar(255) not null,
    primary key (moneyDistributionTicketId)
);

create table MoneyDistributionTicketReceipt
(
    moneyDistributionTicketReceiptId int(11)   NOT NULL AUTO_INCREMENT,
    insertDateTime                   timestamp not null,
    updateDateTime                   timestamp not null,
    createdDateTime                  timestamp not null,
    money                            bigint    not null,
    moneyDistributionId              bigint    not null,
    moneyDistributionTicketId        bigint    not null,
    userId                           bigint    not null,
    primary key (moneyDistributionTicketReceiptId)
);

create table User
(
    userId         int(11)      NOT NULL AUTO_INCREMENT,
    insertDateTime timestamp    not null,
    updateDateTime timestamp    not null,
    userName       varchar(255) not null,
    primary key (userId)
);
create index IDXkwulvtfljbhmtsabcrsspjr2k on MoneyDistribution (token);

alter table MoneyDistributionTicketReceipt
    add constraint UK6bemqdf12hf7oy7vpofsux3si unique (userId, moneyDistributionId)