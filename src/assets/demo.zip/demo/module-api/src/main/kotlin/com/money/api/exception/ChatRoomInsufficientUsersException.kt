package com.money.api.exception

/**
 * @author traeper
 */
class ChatRoomInsufficientUsersException : RuntimeException {
    constructor() : super()
}
