package com.money.api.presentation.model

/**
 * @author traeper
 */
data class ApiResponse<T>(
    val isSuccess: Boolean,
    val code: ApiResponseCode,
    val data: T?
) {
    companion object {
        fun <T> success(data: T): ApiResponse<T> {
            return ApiResponse(
                isSuccess = true,
                code = ApiResponseCode.SUCCESS,
                data = data
            )
        }

        fun <T> fail(code: ApiResponseCode, data: T? = null): ApiResponse<T> {
            return ApiResponse(
                isSuccess = false,
                code = code,
                data = data
            )
        }
    }
}
