package com.money.api.presentation.model

import com.money.domain.distribution.service.model.DistributionResult
import com.money.domain.distribution.service.model.ReceiptDetail
import java.time.ZonedDateTime

/**
 * @author traeper
 */
data class DistributionResultResponse(
    val distributionDateTime: ZonedDateTime,
    val totalMoney: Long,
    val totalReceiptMoney: Long,
    val receiptDetailResponseList: List<ReceiptDetailResponse>
) {
    companion object {
        fun from(result: DistributionResult): DistributionResultResponse {
            return DistributionResultResponse(
                distributionDateTime = result.distributionDateTime,
                totalMoney = result.totalMoney,
                totalReceiptMoney = result.totalReceiptMoney,
                receiptDetailResponseList = result.receiptDetailList
                    .map { ReceiptDetailResponse.from(it) }
            )
        }
    }
}

data class ReceiptDetailResponse(
    val userId: Long,
    val userName: String,
    val receiptMoney: Long
) {
    companion object {
        fun from(detail: ReceiptDetail): ReceiptDetailResponse {
            return ReceiptDetailResponse(
                userId = detail.userId,
                userName = detail.userName,
                receiptMoney = detail.receiptMoney
            )
        }
    }
}
