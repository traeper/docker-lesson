package com.money.api.exception

/**
 * @author traeper
 */
class AlreadyReceivedMoneyException : RuntimeException()
