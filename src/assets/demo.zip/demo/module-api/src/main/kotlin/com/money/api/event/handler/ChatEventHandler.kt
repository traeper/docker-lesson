package com.money.api.event.handler

import com.money.api.event.DefaultEvent
import com.money.api.event.`object`.ChatRoomMoneyDistributed
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional
import org.springframework.transaction.event.TransactionPhase
import org.springframework.transaction.event.TransactionalEventListener

/**
 * @author traeper
 */
@Service
class ChatEventHandler {

    @TransactionalEventListener(phase = TransactionPhase.BEFORE_COMMIT)
    @Transactional
    fun chatRoomMoneyDistributed(defaultEvent: DefaultEvent<ChatRoomMoneyDistributed>) {
        // TODO chat data create
        // TODO call ChatDataCreated Event for push alarm
    }
}
