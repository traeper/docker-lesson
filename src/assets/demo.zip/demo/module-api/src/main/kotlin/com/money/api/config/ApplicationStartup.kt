package com.money.api.config

import com.money.api.application.UserChatRoomMoneyDistributionService
import com.money.common.util.RandomStringGenerator
import com.money.domain.chat.ChatRoomEntity
import com.money.domain.chat.ChatRoomRepository
import com.money.domain.chat.ChatRoomUserEntity
import com.money.domain.chat.ChatRoomUserRepository
import com.money.domain.transaction.AccountEntity
import com.money.domain.transaction.AccountRepository
import com.money.domain.user.UserEntity
import com.money.domain.user.UserRepository
import mu.KotlinLogging
import org.springframework.boot.context.event.ApplicationReadyEvent
import org.springframework.context.ApplicationListener
import org.springframework.context.annotation.Profile
import org.springframework.stereotype.Component

/**
 * @author traeper
 */
@Profile("demo")
@Component
class ApplicationStartup(
    private val userRepository: UserRepository,
    private val accountRepository: AccountRepository,
    private val chatRoomRepository: ChatRoomRepository,
    private val chatRoomUserRepository: ChatRoomUserRepository,
    private val userChatRoomMoneyDistributionService: UserChatRoomMoneyDistributionService
) : ApplicationListener<ApplicationReadyEvent> {

    private val log = KotlinLogging.logger { }

    override fun onApplicationEvent(event: ApplicationReadyEvent) {
        val chatRoomCount = 4
        val users = iter(20) { userRepository.save(UserEntity(userName = RandomStringGenerator.generate(5))) }
        val chatRooms = iter(chatRoomCount) { chatRoomRepository.save(ChatRoomEntity()) }

        // 유저 별 계좌 생성
        users.forEach {
            accountRepository.save(AccountEntity(userId = it.getId(), balance = 50000000L))
        }

        // 유저 채팅방 입장
        (0 until chatRoomCount).forEach { roomIdx ->
            users.subList(5 * roomIdx, 5 * (roomIdx + 1))
                .forEach { user ->
                    chatRoomUserRepository.save(
                        ChatRoomUserEntity(
                            chatRoomId = chatRooms[roomIdx].getId(),
                            userId = user.getId()
                        )
                    )
                }
        }

        // 첫 유저 돈 뿌리기 실행
        val firstUserId = users.first().getId()
        val firstChatRoomId = chatRooms.first().getId()
        val token = userChatRoomMoneyDistributionService.distributeMoney(
            userId = firstUserId,
            chatRoomId = firstChatRoomId,
            totalMoney = 100000L,
            distributionCount = 3
        )

        log.info { "돈 뿌리기 서버가 실행되었습니다. API 호출 테스트 전에 아래 채팅방, userId 정보를 백업해주세요." }

        var i = 0
        chatRooms.forEach {
            log.info { "- 채팅방#$i roomId : ${it.chatRoomId}, userIds : ${1 + 5 * i} ~ ${5 * (i + 1)} " }
            i++
        }

        log.info { "<돈 뿌리기 완료> 뿌린사람 userId : $firstUserId, roomId $firstChatRoomId, Token : $token" }

        log.info { "Swagger -- http://localhost:8080/swagger-ui/index.html" }
        log.info { "H2DB -- http://localhost:8080/h2" }
    }

    private fun <T> iter(cnt: Int, supplier: () -> T): List<T> {
        val result = mutableListOf<T>()
        repeat(cnt) {
            result.add(supplier.invoke())
        }
        return result
    }
}
