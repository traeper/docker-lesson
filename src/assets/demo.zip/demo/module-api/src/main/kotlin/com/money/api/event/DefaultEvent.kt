package com.money.api.event

import org.springframework.context.ApplicationEvent
import org.springframework.core.ResolvableType
import org.springframework.core.ResolvableTypeProvider

/**
 * @author traeper
 */
data class DefaultEvent<T : Any> (
    val event: T
) : ApplicationEvent(event), ResolvableTypeProvider {
    override fun getResolvableType(): ResolvableType? {
        return ResolvableType.forClassWithGenerics(
            javaClass,
            ResolvableType.forInstance(source)
        )
    }
}
