package com.money.api.presentation.authorization

import com.money.api.exception.AlreadyReceivedMoneyException
import com.money.api.exception.ForbiddenException
import com.money.api.exception.ReceiveOwnMoneyException
import com.money.domain.chat.ChatRoomUserRepository
import com.money.domain.distribution.MoneyDistributionRepository
import com.money.domain.distribution.MoneyDistributionTicketReceiptRepository
import com.money.domain.distribution.chat.ChatRoomMoneyDistributionRepository
import org.springframework.stereotype.Service

/**
 * @author traeper
 */
@Service
class ChatRoomMoneyDistributionAuthorizer(
    private val moneyDistributionRepository: MoneyDistributionRepository,
    private val chatRoomMoneyDistributionRepository: ChatRoomMoneyDistributionRepository,
    private val chatRoomUserRepository: ChatRoomUserRepository,
    private val moneyDistributionTicketReceiptRepository: MoneyDistributionTicketReceiptRepository
) {
    fun hasReceiveAuthority(userId: Long, token: String): Boolean {
        val distribution = moneyDistributionRepository.findByToken(token)
            ?: throw ForbiddenException("FORBIDDEN")

        if (distribution.userId == userId) {
            throw ReceiveOwnMoneyException()
        }

        // 분배건에 대한 채팅방 정보 조회
        val chatRoomDistribution =
            chatRoomMoneyDistributionRepository.findByMoneyDistributionId(distribution.getId())
                ?: throw ForbiddenException("FORBIDDEN")
        // 유저가 속한 채팅방인지 확인
        chatRoomUserRepository.findByChatRoomIdAndUserId(chatRoomDistribution.chatRoomId, userId)
            ?: throw ForbiddenException("FORBIDDEN")

        // 이미 본 분배건을 1회 수령했는지 확인
        val moneyDistributionTicketReceipt = moneyDistributionTicketReceiptRepository.findByUserIdAndMoneyDistributionId(
            userId = userId,
            moneyDistributionId = distribution.getId()
        )
        if (moneyDistributionTicketReceipt != null) {
            throw AlreadyReceivedMoneyException()
        }

        return true
    }

    fun hasSearchAuthority(userId: Long, token: String): Boolean {
        val moneyDistribution = moneyDistributionRepository.findByToken(token)
            ?: throw ForbiddenException("FORBIDDEN")

        if (moneyDistribution.userId != userId) {
            // 자신의 것이 아니니 NOT_FOUND로 자원이 없는 것처럼 꾸미는 것도 방법으로 보임.
            throw ForbiddenException("FORBIDDEN")
        }

        return true
    }
}
