package com.money.api.event.`object`

import java.util.UUID

/**
 * 사용처
 * 1. 채팅이 생겼을 때 발생하는 이벤트
 * @author traeper
 * TODO 상세구현
 */
data class ChatCreated(
    val chatRoomId: UUID,
    val userId: Long,
    val message: String
)
