package com.money.api.config.converter

import org.springframework.core.convert.converter.Converter
import org.springframework.stereotype.Component
import java.util.UUID

/**
 * @author traeper
 */
@Component
class UuidConverter : Converter<String, UUID> {
    override fun convert(source: String): UUID {
        return UUID.fromString(source)
    }
}
