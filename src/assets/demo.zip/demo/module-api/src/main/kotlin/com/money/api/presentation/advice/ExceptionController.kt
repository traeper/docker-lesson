package com.money.api.presentation.advice

import com.money.api.exception.AlreadyReceivedMoneyException
import com.money.api.exception.ChatRoomInsufficientUsersException
import com.money.api.exception.ForbiddenException
import com.money.api.exception.ReceiveOwnMoneyException
import com.money.api.presentation.model.ApiResponse
import com.money.api.presentation.model.ApiResponseCode
import com.money.domain.distribution.exception.DistributionDoneException
import com.money.domain.distribution.exception.SearchDisabledException
import mu.KotlinLogging
import org.springframework.http.HttpStatus
import org.springframework.validation.BindException
import org.springframework.web.bind.MethodArgumentNotValidException
import org.springframework.web.bind.annotation.ExceptionHandler
import org.springframework.web.bind.annotation.ResponseStatus
import org.springframework.web.bind.annotation.RestControllerAdvice
import javax.validation.ConstraintViolationException

/**
 * @author traeper
 */
@RestControllerAdvice
class ExceptionController {
    private val log = KotlinLogging.logger { }

    @ExceptionHandler(value = [BindException::class, MethodArgumentNotValidException::class])
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    fun handleMethodArgumentNotValidException(ex: Exception): ApiResponse<Any> {

        var errorMessage: String? = null
        if (ex is BindException) {
            errorMessage = ex.bindingResult.allErrors[0].defaultMessage
        } else if (ex is MethodArgumentNotValidException) {
            errorMessage = ex.bindingResult.allErrors[0].defaultMessage
        }
        return ApiResponse.fail(ApiResponseCode.BAD_REQUEST, errorMessage)
    }

    @ExceptionHandler(ConstraintViolationException::class)
    fun handleConstraintViolationException(ex: ConstraintViolationException): ApiResponse<Any> {
        val errorMessage = ex.constraintViolations.first().message
        return ApiResponse.fail(ApiResponseCode.BAD_REQUEST, errorMessage)
    }

    @ExceptionHandler(Throwable::class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    fun unhandledException(throwable: Throwable): ApiResponse<Any> {
        log.error(throwable.message, throwable)
        return ApiResponse.fail(ApiResponseCode.UNKNOWN_ERROR)
    }

    @ExceptionHandler(ForbiddenException::class)
    @ResponseStatus(HttpStatus.FORBIDDEN)
    fun forbiddenException(forbiddenException: ForbiddenException): ApiResponse<Any> {
        log.info(forbiddenException.message)
        return ApiResponse.fail(ApiResponseCode.FORBIDDEN)
    }

    @ExceptionHandler(ChatRoomInsufficientUsersException::class)
    @ResponseStatus(HttpStatus.FORBIDDEN)
    fun chatRoomInsufficientUsersException(chatRoomInsufficientUsersException: ChatRoomInsufficientUsersException): ApiResponse<Any> {
        log.info(chatRoomInsufficientUsersException.message)
        return ApiResponse.fail(ApiResponseCode.CHAT_ROOM_INSUFFICIENT_USERS)
    }

    @ExceptionHandler(ReceiveOwnMoneyException::class)
    @ResponseStatus(HttpStatus.FORBIDDEN)
    fun forbiddenReceivingOwnMoneyDistributionException(receiveOwnMoneyException: ReceiveOwnMoneyException): ApiResponse<Any> {
        log.info(receiveOwnMoneyException.message)
        return ApiResponse.fail(ApiResponseCode.RECEIVE_OWN_MONEY)
    }

    @ExceptionHandler(AlreadyReceivedMoneyException::class)
    @ResponseStatus(HttpStatus.FORBIDDEN)
    fun alreadyReceiveMoneyException(alreadyReceivedMoneyException: AlreadyReceivedMoneyException): ApiResponse<Any> {
        log.info(alreadyReceivedMoneyException.message)
        return ApiResponse.fail(ApiResponseCode.ALREADY_RECEIVED_MONEY)
    }

    @ExceptionHandler(DistributionDoneException::class)
    @ResponseStatus(HttpStatus.FORBIDDEN)
    fun distributionDoneException(distributionDoneException: DistributionDoneException): ApiResponse<Any> {
        log.info(distributionDoneException.message)
        return ApiResponse.fail(ApiResponseCode.DISTRIBUTION_DONE)
    }

    @ExceptionHandler(SearchDisabledException::class)
    @ResponseStatus(HttpStatus.FORBIDDEN)
    fun searchDisabledException(searchDisabledException: SearchDisabledException): ApiResponse<Any> {
        log.info(searchDisabledException.message)
        return ApiResponse.fail(ApiResponseCode.SEARCH_DISABLED)
    }
}
