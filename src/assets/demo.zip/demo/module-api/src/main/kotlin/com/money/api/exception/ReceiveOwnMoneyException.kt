package com.money.api.exception

/**
 * @author traeper
 * 자신이 뿌리기 한 건에서 돈을 받으려는 경우®
 */
class ReceiveOwnMoneyException : RuntimeException {
    constructor() : super()
}
