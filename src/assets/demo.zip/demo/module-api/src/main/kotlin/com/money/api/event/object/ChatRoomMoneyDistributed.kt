package com.money.api.event.`object`

import java.util.UUID

/**
 * 사용처
 * 1. 회원 계좌 잔액 변동 수행
 * 2. 채팅방 푸시 알람
 * @author traeper
 */
data class ChatRoomMoneyDistributed(
    val userId: Long,
    val chatRoomId: UUID,
    val moneyDistributionId: Long,
    val totalMoney: Long,
    val distributionCount: Int
)
