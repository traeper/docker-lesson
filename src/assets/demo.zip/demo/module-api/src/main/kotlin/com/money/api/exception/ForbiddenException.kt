package com.money.api.exception

/**
 * @author traeper
 */
class ForbiddenException : RuntimeException {
    constructor() : super()
    constructor(message: String) : super(message)
}
