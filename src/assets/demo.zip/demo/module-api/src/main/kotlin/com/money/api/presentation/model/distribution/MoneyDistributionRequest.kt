package com.money.api.presentation.model.distribution

import javax.validation.constraints.Min

/**
 * @author traeper
 */
data class MoneyDistributionRequest(
    @get:Min(1L)
    val totalMoney: Long,
    @get:Min(1L)
    val distributionCount: Int
)
