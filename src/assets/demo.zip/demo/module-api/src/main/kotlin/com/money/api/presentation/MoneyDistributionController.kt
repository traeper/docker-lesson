package com.money.api.presentation

import com.money.api.application.UserChatRoomMoneyDistributionService
import com.money.api.presentation.model.ApiResponse
import com.money.api.presentation.model.DistributionResultResponse
import com.money.api.presentation.model.distribution.MoneyDistributionRequest
import org.springframework.security.access.prepost.PreAuthorize
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestHeader
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController
import java.util.UUID
import javax.validation.Valid

/**
 * @author traeper
 */
@RestController
@RequestMapping("/v1/moneyDistributions")
class MoneyDistributionController(
    val userChatRoomMoneyDistributionService: UserChatRoomMoneyDistributionService
) {
    @PreAuthorize("@userChatRoomAuthorizer.hasRoomAuthority(#userId, #chatRoomId)")
    @PostMapping
    fun distributeMoney(
        @RequestHeader("X-USER-ID") userId: Long,
        @RequestHeader("X-ROOM-ID") chatRoomId: UUID,
        @RequestBody @Valid moneyDistributionRequest: MoneyDistributionRequest
    ): ApiResponse<String> {
        val token = userChatRoomMoneyDistributionService.distributeMoney(
            userId = userId,
            chatRoomId = chatRoomId,
            totalMoney = moneyDistributionRequest.totalMoney,
            distributionCount = moneyDistributionRequest.distributionCount
        )

        return ApiResponse.success(token)
    }

    @PreAuthorize("@chatRoomMoneyDistributionAuthorizer.hasReceiveAuthority(#userId, #token)")
    @GetMapping("/{token}/receive")
    fun receiveMoney(
        @RequestHeader("X-USER-ID") userId: Long,
        @PathVariable token: String
    ): ApiResponse<Long> {
        val money = userChatRoomMoneyDistributionService.receiveMoney(
            userId = userId,
            token = token
        )

        return ApiResponse.success(money)
    }

    @PreAuthorize("@chatRoomMoneyDistributionAuthorizer.hasSearchAuthority(#userId, #token)")
    @GetMapping("/{token}")
    fun getMoneyDistribution(
        @RequestHeader("X-USER-ID") userId: Long,
        @PathVariable token: String
    ): ApiResponse<DistributionResultResponse> {
        val distributionResult = userChatRoomMoneyDistributionService.getMoneyDistributionResult(
            token = token
        )
        return ApiResponse.success(DistributionResultResponse.from(distributionResult))
    }
}
