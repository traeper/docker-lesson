package com.money.api.event.`object`

/**
 * 사용처
 * 1. 회원 계좌 잔액 변동 수행
 * 2. 채팅방 푸시 알람 (만약 남은 뿌리기 건 갯수 등을 내려줄 필요가 있다면)
 * @author traeper
 */
data class ChatRoomMoneyReceived(
    val userId: Long,
    val moneyDistributionId: Long,
    val money: Long
)
