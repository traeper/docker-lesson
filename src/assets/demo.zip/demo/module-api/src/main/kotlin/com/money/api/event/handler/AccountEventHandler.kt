package com.money.api.event.handler

import com.money.api.event.DefaultEvent
import com.money.api.event.`object`.ChatRoomMoneyDistributed
import com.money.api.event.`object`.ChatRoomMoneyReceived
import com.money.domain.transaction.AccountRepository
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional
import org.springframework.transaction.event.TransactionPhase
import org.springframework.transaction.event.TransactionalEventListener

/**
 * @author traeper
 */
@Service
class AccountEventHandler(
    private val accountRepository: AccountRepository
) {

    @TransactionalEventListener(phase = TransactionPhase.BEFORE_COMMIT)
    @Transactional
    fun subtractBalanceChatRoomMoney(defaultEvent: DefaultEvent<ChatRoomMoneyDistributed>) {
        val event = defaultEvent.event

        val account = accountRepository.findByUserId(event.userId)
        account.subtractBalance(event.totalMoney)
    }

    @TransactionalEventListener(phase = TransactionPhase.BEFORE_COMMIT)
    @Transactional
    fun addBalanceChatRoomMoney(defaultEvent: DefaultEvent<ChatRoomMoneyReceived>) {
        val event = defaultEvent.event

        val account = accountRepository.findByUserId(event.userId)
        account.addBalance(event.money)
    }
}
