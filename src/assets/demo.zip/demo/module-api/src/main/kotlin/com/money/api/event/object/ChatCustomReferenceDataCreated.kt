package com.money.api.event.`object`

import java.util.UUID

/**
 * @author traeper
 */
data class ChatCustomReferenceDataCreated(
    val userId: Long,
    val chatRoomId: UUID,
    val moneyDistributionId: Long,
    val totalMoney: Long,
    val distributionCount: Int
)
