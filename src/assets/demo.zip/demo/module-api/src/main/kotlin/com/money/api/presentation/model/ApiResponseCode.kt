package com.money.api.presentation.model

/**
 * @author traeper
 */
enum class ApiResponseCode {
    SUCCESS,
    BAD_REQUEST,
    UNKNOWN_ERROR,
    FORBIDDEN, // 기타 권한 에러 코드
    RECEIVE_OWN_MONEY, // 내가 뿌리기한 것을 받을 수 없다
    CHAT_ROOM_INSUFFICIENT_USERS, // 채팅방 유저 부족
    ALREADY_RECEIVED_MONEY, // 돈 이미 받음
    DISTRIBUTION_DONE, // 분배 종료
    SEARCH_DISABLED // 검색 불가
}
