package com.money.api.application

import com.money.api.event.DefaultEvent
import com.money.api.event.`object`.ChatRoomMoneyDistributed
import com.money.api.event.`object`.ChatRoomMoneyReceived
import com.money.api.exception.ChatRoomInsufficientUsersException
import com.money.common.util.NumberDistributor
import com.money.common.util.RandomStringGenerator
import com.money.domain.chat.ChatRoomUserRepository
import com.money.domain.distribution.chat.ChatRoomMoneyDistributionEntity
import com.money.domain.distribution.chat.ChatRoomMoneyDistributionRepository
import com.money.domain.distribution.service.MoneyDistributionService
import com.money.domain.distribution.service.model.DistributionResult
import com.money.domain.transaction.AccountRepository
import org.springframework.context.ApplicationEventPublisher
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional
import java.util.UUID

/**
 * @author traeper
 * @property moneyDistributionService 돈 분배 도메인서비스
 * @property accountRepository 회원 계좌 리포지토리
 * @property chatRoomUserRepository 채팅방 - 유저 관계 리포지토리
 * @property chatRoomMoneyDistributionRepository 돈분배가 진행된 채팅방
 * @property applicationEventPublisher 이벤트 발생기
 */
@Service
class UserChatRoomMoneyDistributionService(
    private val moneyDistributionService: MoneyDistributionService,
    private val accountRepository: AccountRepository,
    private val chatRoomUserRepository: ChatRoomUserRepository,
    private val chatRoomMoneyDistributionRepository: ChatRoomMoneyDistributionRepository,
    private val applicationEventPublisher: ApplicationEventPublisher
) {

    /**
     * @return access token
     */
    @Transactional
    fun distributeMoney(
        userId: Long,
        chatRoomId: UUID,
        totalMoney: Long,
        distributionCount: Int
    ): String {
        // 돈 분배
        val moneyDistribution = moneyDistributionService.distributeMoney(
            userId = userId,
            totalMoney = totalMoney,
            distributionCount = distributionCount,
            token = RandomStringGenerator.generate(3),
            numberDistributor = NumberDistributor::distribute
        )

        // 채팅방 사용자 수 확인
        val chatRoomUsers = chatRoomUserRepository.findByChatRoomId(chatRoomId)
        val otherChatRoomUsers = chatRoomUsers.filter { it.userId != userId }
        if (otherChatRoomUsers.size < distributionCount) {
            throw ChatRoomInsufficientUsersException()
        }

        // 채팅방 연결
        chatRoomMoneyDistributionRepository.save(
            ChatRoomMoneyDistributionEntity.create(
                chatRoomId = chatRoomId,
                moneyDistributionId = moneyDistribution.getId()
            )
        )

        // 돈 분배 완료 이벤트 publish
        applicationEventPublisher.publishEvent(
            DefaultEvent(
                ChatRoomMoneyDistributed(
                    userId = userId,
                    chatRoomId = chatRoomId,
                    moneyDistributionId = moneyDistribution.getId(),
                    totalMoney = totalMoney,
                    distributionCount = distributionCount,
                )
            )
        )

        return moneyDistribution.token
    }

    /**
     * @return money
     */
    @Transactional
    fun receiveMoney(userId: Long, token: String): Long {
        val ticket = moneyDistributionService.receiveMoney(userId, token)

        // 돈 받기 완료 이벤트 publish
        applicationEventPublisher.publishEvent(
            DefaultEvent(
                ChatRoomMoneyReceived(
                    userId = userId,
                    moneyDistributionId = ticket.moneyDistributionId,
                    money = ticket.money
                )
            )
        )

        return ticket.money
    }

    @Transactional
    fun getMoneyDistributionResult(token: String): DistributionResult {
        return moneyDistributionService.getMoneyDistributionResult(token)
    }
}
