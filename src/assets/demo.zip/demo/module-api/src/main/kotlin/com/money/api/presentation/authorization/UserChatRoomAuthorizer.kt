package com.money.api.presentation.authorization

import com.money.api.exception.ForbiddenException
import com.money.domain.chat.ChatRoomUserRepository
import org.springframework.stereotype.Service
import java.util.UUID

/**
 * @author traeper
 */
@Service
class UserChatRoomAuthorizer(
    private val chatRoomUserRepository: ChatRoomUserRepository
) {
    fun hasRoomAuthority(userId: Long, chatRoomId: UUID): Boolean {
        chatRoomUserRepository.findByChatRoomIdAndUserId(chatRoomId, userId)
            ?: throw ForbiddenException("FORBIDDEN")

        return true
    }
}
