import org.gradle.api.tasks.bundling.Jar
import org.springframework.boot.gradle.tasks.bundling.BootJar

val jar: Jar by tasks
val bootJar: BootJar by tasks

bootJar.enabled = false
jar.enabled = true

buildscript {
    repositories {
        mavenCentral()
    }

    dependencies {
        val kotlinVersion = rootProject.extra.get("kotlinVersion")
        classpath("org.jetbrains.kotlin:kotlin-noarg:$kotlinVersion")
        classpath("org.jetbrains.kotlin:kotlin-allopen:$kotlinVersion")
    }
}

plugins {
    kotlin("jvm")
}

dependencies {
    val reactorVersion = rootProject.extra.get("reactorVersion")
    api("io.projectreactor:reactor-core:$reactorVersion")
    implementation("io.projectreactor.kotlin:reactor-kotlin-extensions:1.0.2.RELEASE")

    testImplementation("org.springframework.boot:spring-boot-starter-test")
}
