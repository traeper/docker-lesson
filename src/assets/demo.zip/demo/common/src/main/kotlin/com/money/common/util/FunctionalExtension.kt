package com.money.common.util

import com.money.common.exception.NotFoundException
import java.util.Optional

/**
 * @author traeper
 */
fun <T> Optional<T>.orElseThrow(throwable: Throwable? = null): T {
    return this.orElseThrow { throwable ?: NotFoundException() }
}

fun <T> T?.orElseThrow(throwable: Throwable? = null): T {
    return this ?: throw (throwable ?: NotFoundException())
}
