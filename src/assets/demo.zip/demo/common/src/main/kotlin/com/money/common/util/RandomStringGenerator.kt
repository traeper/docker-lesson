package com.money.common.util

import java.security.SecureRandom

/**
 * @author traeper
 */
object RandomStringGenerator {
    const val source = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
    private val rnd: SecureRandom = SecureRandom()

    fun generate(len: Int): String {
        val sb = StringBuilder(len)
        for (i in 0 until len) sb.append(source[rnd.nextInt(source.length)])
        return sb.toString()
    }
}
