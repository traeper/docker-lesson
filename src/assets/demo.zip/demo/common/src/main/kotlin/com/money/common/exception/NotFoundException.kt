package com.money.common.exception

/**
 * @author traeper
 */
class NotFoundException : RuntimeException()
