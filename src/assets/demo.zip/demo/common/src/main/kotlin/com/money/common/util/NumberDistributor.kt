package com.money.common.util

import kotlin.collections.ArrayList

object NumberDistributor {
    fun distribute(value: Long, distributionCount: Int): List<Long> {
        val share = value / distributionCount
        val remain = value % distributionCount

        val list = ArrayList<Long>(distributionCount)
        repeat(distributionCount) {
            if (it < distributionCount - 1) {
                list.add(share)
            } else {
                list.add(share + remain)
            }
        }
        return list
    }
}
