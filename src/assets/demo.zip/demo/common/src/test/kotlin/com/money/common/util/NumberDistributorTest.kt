package com.money.common.util

import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Test

/**
 * @author traeper
 */
class NumberDistributorTest {

    @Test
    internal fun `DefaultNumberDistributor distribution Test - no remain`() {
        // GIVEN
        val value = 10000L
        val distributionCount = 5

        // WHEN
        val distributed = NumberDistributor.distribute(value, distributionCount)

        // THEN
        assertThat(distributed.sum()).isEqualTo(value)
        assertThat(distributed.size).isEqualTo(distributionCount)
    }

    @Test
    internal fun `DefaultNumberDistributor distribution Test - remain`() {
        // GIVEN
        val value = 134L
        val distributionCount = 3

        // WHEN
        val distributed = NumberDistributor.distribute(value, distributionCount)

        // THEN
        assertThat(distributed.sum()).isEqualTo(value)
        assertThat(distributed.size).isEqualTo(distributionCount)
    }
}
