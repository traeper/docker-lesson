rootProject.name = "demo"

include("common")
include("ddd-core")
include("domain")
include("module-api")
